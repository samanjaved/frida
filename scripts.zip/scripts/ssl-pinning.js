Java.perform(function () {
    console.log("[*] SSL Pinning Bypass Initiated");

    // TrustManagerImpl (Android default)
    try {
        var TrustManagerImpl = Java.use('com.android.org.conscrypt.TrustManagerImpl');
        TrustManagerImpl.verifyChain.implementation = function (chain, authType, session, parameters) {
            console.log('[+] Bypassing TrustManagerImpl.verifyChain');
            return chain;
        };
    } catch (err) {
        console.log('[-] TrustManagerImpl not found or already bypassed');
    }

    // OkHttp3 CertificatePinner
    try {
        var CertificatePinner = Java.use('okhttp3.CertificatePinner');
        CertificatePinner.check.overload('java.lang.String', 'java.util.List').implementation = function (hostname, peerCertificates) {
            console.log('[+] Bypassing OkHttp CertificatePinner for host: ' + hostname);
        };
    } catch (err) {
        console.log('[-] OkHttp CertificatePinner not found');
    }

    // WebViewClient SSL error handler
    try {
        var WebViewClient = Java.use('android.webkit.WebViewClient');
        WebViewClient.onReceivedSslError.implementation = function (view, handler, error) {
            console.log('[+] Bypassing WebViewClient.onReceivedSslError');
            handler.proceed();
        };
    } catch (err) {
        console.log('[-] WebViewClient hook failed');
    }

    console.log("[*] SSL Pinning Bypass Hooks Installed");
});
