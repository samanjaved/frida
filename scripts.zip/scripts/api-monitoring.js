Java.perform(function () {
    console.log("[*] Advanced API Monitoring Script Loaded");

    // --- OkHttp Headers ---
    try {
        const RequestBuilder = Java.use('okhttp3.Request$Builder');
        RequestBuilder.addHeader.overload('java.lang.String', 'java.lang.String').implementation = function (name, value) {
            if (name.toLowerCase().includes("authorization") || name.toLowerCase().includes("token") || name.toLowerCase().includes("key")) {
                console.log("[+] OkHttp Header -> " + name + ": " + value);
            }
            return this.addHeader(name, value);
        };
        console.log("[*] Hooked OkHttp Request$Builder.addHeader");
    } catch (err) {
        console.log("[-] OkHttp Request$Builder not found");
    }

    // --- OkHttp URL Logging ---
    try {
        const Request = Java.use("okhttp3.Request");
        Request.url.implementation = function () {
            const url = this.url().toString();
            console.log("[+] OkHttp URL -> " + url);
            return this.url();
        };
        console.log("[*] Hooked okhttp3.Request.url");
    } catch (err) {
        console.log("[-] okhttp3.Request not found");
    }

    // --- SharedPreferences Token Sniffing ---
    try {
        const SharedPreferences = Java.use("android.content.SharedPreferences");
        SharedPreferences.getString.overload('java.lang.String', 'java.lang.String').implementation = function (key, defValue) {
            const value = this.getString(key, defValue);
            if (key.toLowerCase().includes("token") || key.toLowerCase().includes("auth") || key.toLowerCase().includes("apikey")) {
                console.log("[+] SharedPreferences -> " + key + ": " + value);
            }
            return value;
        };
        console.log("[*] Hooked SharedPreferences.getString");
    } catch (err) {
        console.log("[-] SharedPreferences not hooked");
    }

    // --- HttpsURLConnection Header Sniffing ---
    try {
        const HttpsURLConnection = Java.use("javax.net.ssl.HttpsURLConnection");
        HttpsURLConnection.setRequestProperty.overload('java.lang.String', 'java.lang.String').implementation = function (key, value) {
            if (key.toLowerCase().includes("authorization") || key.toLowerCase().includes("token") || key.toLowerCase().includes("key")) {
                console.log("[+] HttpsURLConnection Header -> " + key + ": " + value);
            }
            return this.setRequestProperty(key, value);
        };
        console.log("[*] Hooked HttpsURLConnection.setRequestProperty");
    } catch (err) {
        console.log("[-] HttpsURLConnection not hooked");
    }

    console.log("[*] All Hooks Installed");
});
