// root-bypass.js
Java.perform(function () {
    console.log("[*] Root detection bypass script loaded");

    // Bypass common file existence checks (e.g. /system/xbin/su)
    var File = Java.use("java.io.File");
    File.exists.implementation = function () {
        var path = this.getAbsolutePath();
        if (path.includes("su") || path.toLowerCase().includes("magisk") || path.includes("busybox")) {
            console.log("[+] Bypassing file.exists() for: " + path);
            return false;
        }
        return this.exists.call(this);
    };

    // Bypass Build.TAGS check
    var Build = Java.use("android.os.Build");
    Build.TAGS.value = "release-keys"; // Looks like a production build

    // Bypass Runtime.exec("su")
    var Runtime = Java.use("java.lang.Runtime");
    Runtime.exec.overload('java.lang.String').implementation = function (cmd) {
        if (cmd.toLowerCase().includes("su")) {
            console.log("[+] Bypassing Runtime.exec: " + cmd);
            throw new Error("Access Denied");
        }
        return this.exec.call(this, cmd);
    };

    // Bypass System.getenv("PATH") leaking root paths
    var System = Java.use("java.lang.System");
    System.getenv.overload('java.lang.String').implementation = function (name) {
        if (name === "PATH") {
            console.log("[+] Bypassing System.getenv('PATH')");
            return "/usr/bin:/bin"; // sanitized path
        }
        return this.getenv(name);
    };

    console.log("[*] Root detection bypass hooks installed");
});
